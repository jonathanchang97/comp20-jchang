# assignment 2

* Identify what aspects of the work have been correctly implemented and what have not.
    Everything has been correctly implemented

* Identify anyone with whom you have collaborated or discussed the assignment: 
    No collaboration or discussions.  Utilized the ajax and examples folders in the comp20 github for guidance.

* Say approximately how many hours you have spent completing the assignment.
		6 hours
